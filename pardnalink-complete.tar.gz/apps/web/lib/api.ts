const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/v1';

export const api = {
  // Circles
  getCircles: () => fetch(`${API_BASE}/circles`).then(r => r.json()),
  createCircle: (data: any) => fetch(`${API_BASE}/circles`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(r => r.json()),
  
  // Members
  getCircleMembers: (circleId: string) => 
    fetch(`${API_BASE}/circles/${circleId}/members`).then(r => r.json()),
  
  // Rounds
  getCircleRounds: (circleId: string) => 
    fetch(`${API_BASE}/circles/${circleId}/rounds`).then(r => r.json()),
  createRound: (circleId: string, data: any) => 
    fetch(`${API_BASE}/circles/${circleId}/rounds`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    }).then(r => r.json()),
  
  // Payments
  getCirclePayments: (circleId: string) => 
    fetch(`${API_BASE}/circles/${circleId}/payments`).then(r => r.json()),
  createPayment: (circleId: string, data: any) => 
    fetch(`${API_BASE}/circles/${circleId}/payments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    }).then(r => r.json())
};