export const metadata={title:'Digital Pardna',description:'Community savings'};
export default function RootLayout({children}:{children:React.ReactNode}){return(<html lang='en'><body style={{fontFamily:'system-ui',margin:0}}><div style={{maxWidth:880,margin:'0 auto',padding:16}}>{children}</div></body></html>)}
