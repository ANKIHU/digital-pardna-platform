import 'dotenv/config';
import Fastify from 'fastify';
import { appRoutes } from './routes/index.js';
const app=Fastify({logger:true});
app.addHook('preHandler',(req,reply,done)=>{reply.header('Access-Control-Allow-Origin','*');done();});
app.addHook('preSerialization', async (request, reply, payload) => {
  return JSON.parse(JSON.stringify(payload, (key, value) =>
    typeof value === 'bigint' ? value.toString() : value
  ));
});
await app.register(appRoutes,{prefix:'/v1'});
const port=Number(process.env.PORT||3007);
app.listen({port,host:'0.0.0.0'}).then(()=>{app.log.info(`API http://localhost:${port}`);}).catch(e=>{app.log.error(e);process.exit(1)});
