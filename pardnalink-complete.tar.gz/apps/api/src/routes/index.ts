
import { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
// import { PrismaClient } from '@prisma/client';
import circlesRoutes from './circles.js';
import membersRoutes from './members.js';
import paymentsRoutes from './payments.js';
import roundsRoutes from './rounds.js';
// const prisma = new PrismaClient();

export const appRoutes: FastifyPluginAsync = async (app) => {
  app.get('/health', async () => ({ ok: true }));
  await app.register(circlesRoutes);
  await app.register(membersRoutes);
  await app.register(paymentsRoutes);
  await app.register(roundsRoutes);
};
